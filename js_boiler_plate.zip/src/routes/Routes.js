import React from 'react'
import Pages from '../pages'

const Routes = () => {
    return (
        <>
            <Pages />
        </>
    )
}

export default Routes