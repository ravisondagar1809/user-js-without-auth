import { Provider } from 'react-redux';
import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import './App.css';
import Routes from './routes/Routes';
import store from './redux/store';

function App() {
  return (
    <React.Suspense fallback={false}>
      <Provider store={store}>
        <BrowserRouter>
          <Routes />
        </BrowserRouter>
      </Provider>
    </React.Suspense>
  );
}

export default App;
