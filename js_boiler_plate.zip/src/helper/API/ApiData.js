import { API } from "../../config/API/api.config";
import AuthStorage from "../AuthStorage";
export const BaseURL = API.endpoint + "/";
const axios = require("axios").default;

const defaultHeaders = {
  isAuth: true,
  AdditionalParams: {},
  isJsonRequest: true,
};

export const ApiGet = (type, header = defaultHeaders) => {
  return new Promise((resolve, reject) => {
    const s = type.includes("?") ? "&" : "?";
    axios
      .get(BaseURL + type + `${s}lang=en`, getHttpOptions(header))
      .then((responseJson) => {
        resolve(responseJson.data);
        // console.log(responseJson);
      })
      .catch((error) => {
        if (
          error &&
          error.hasOwnProperty("response") &&
          error.response &&
          error.response.hasOwnProperty("data") &&
          error.response.data &&
          error.response.data.hasOwnProperty("error") &&
          error.response.data.error
        ) {
          reject(error.response.data.error);
        } else {
          reject(error);
        }
      });
  });
};

export const ApiDelete = (type, header = defaultHeaders) => {
  return new Promise((resolve, reject) => {
    const s = type.includes("?") ? "&" : "?";
    axios
      .delete(BaseURL + type + `${s}lang=en`, getHttpOptions(header))
      .then((responseJson) => {
        resolve(responseJson.data);
        // console.log(responseJson);
      })
      .catch((error) => {
        if (
          error &&
          error.hasOwnProperty("response") &&
          error.response &&
          error.response.hasOwnProperty("data") &&
          error.response.data &&
          error.response.data.hasOwnProperty("error") &&
          error.response.data.error
        ) {
          reject(error.response.data.error);
        } else {
          reject(error);
        }
      });
  });
};

export const ApiPut = (type, data) => {
  return new Promise((resolve, reject) => {
    const s = type.includes("?") ? "&" : "?";
    axios
      .put(BaseURL + type + `${s}lang=en`, data, getHttpOptions())
      .then((responseJson) => {
        resolve(responseJson.data);
        // console.log(responseJson);
      })
      .catch((error) => {
        if (
          error &&
          error.hasOwnProperty("response") &&
          error.response &&
          error.response.hasOwnProperty("data") &&
          error.response.data &&
          error.response.data.hasOwnProperty("error") &&
          error.response.data.error
        ) {
          reject(error.response.data.error);
        } else {
          reject(error);
        }
      });
  });
};

export const ApiPatch = (type, data) => {
  return new Promise((resolve, reject) => {
    const s = type.includes("?") ? "&" : "?";
    axios
      .patch(BaseURL + type + `${s}lang=en`, data, getHttpOptions())
      .then((responseJson) => {
        resolve(responseJson.data);
        // console.log(responseJson);
      })
      .catch((error) => {
        if (
          error &&
          error.hasOwnProperty("response") &&
          error.response &&
          error.response.hasOwnProperty("data") &&
          error.response.data &&
          error.response.data.hasOwnProperty("error") &&
          error.response.data.error
        ) {
          reject(error.response.data.error);
        } else {
          reject(error);
        }
      });
  });
};

export const ApiGetNoAuth = (type) => {
  return new Promise((resolve, reject) => {
    const s = type.includes("?") ? "&" : "?";
    axios
      .get(
        BaseURL + type + `${s}lang=en`,
        getHttpOptions({ ...defaultHeaders, isAuth: false })
      )
      .then((responseJson) => {
        resolve(responseJson.data);
      })
      .catch((error) => {
        if (
          error &&
          error.hasOwnProperty("response") &&
          error.response &&
          error.response.hasOwnProperty("data") &&
          error.response.data &&
          error.response.data.hasOwnProperty("error") &&
          error.response.data.error
        ) {
          reject(error.response.data.error);
        } else {
          reject(error);
        }
      });
  });
};

export const ApiPost = (type, userData) => {
  return new Promise((resolve, reject) => {
    const s = type.includes("?") ? "&" : "?";
    axios
      .post(BaseURL + type + `${s}lang=en`, userData, getHttpOptions())
      .then((responseJson) => {
        resolve(responseJson.data);
        // console.log(responseJson);
        if (
          responseJson.data &&
          responseJson.data.data &&
          responseJson.data.data.token
        ) { }
        // Auth.setAuthToken(JSON.stringify(responseJson.data.data.token));
      })
      .catch((error) => {
        if (
          error &&
          error.hasOwnProperty("response") &&
          error.response &&
          error.response.hasOwnProperty("data") &&
          error.response.data &&
          error.response.data.hasOwnProperty("message") &&
          error.response.data.message
        ) {
          reject(error.response.data.message);
        } else {
          reject();
        }
      });
  });
};

export const ApiPostNoAuth = (type, userData) => {
  return new Promise((resolve, reject) => {
    const s = type.includes("?") ? "&" : "?";
      axios.post(`${BaseURL}${type}${s}lang=en`, userData, getHttpOptions({ ...defaultHeaders, isAuth: false }))
          .then((responseJson) => {
              resolve(responseJson.data);
          })
          .catch((error) => {
              if (error?.response?.status === 401) {
                  AuthStorage.deauthenticateUser();
              }
              if (error && error.hasOwnProperty('response') &&
                  error.response && error.response.hasOwnProperty('data') && error.response.data &&
                  error.response.data.hasOwnProperty('message') && error.response.data.message) {
                  reject(error.response.data.message);
              } else {
                  reject(error);
              }
          });
  });
}

// export const getHttpOptions = (options = defaultHeaders) => {
//   let headers = {
//     Authorization: "",
//     "Content-Type": "application/json",
//   };

//   if (options.hasOwnProperty("isAuth") && options.isAuth) {
//     headers["Authorization"] = Auth.getToken() ?? "";
//   }

//   if (options.hasOwnProperty("isJsonRequest") && options.isJsonRequest) {
//     headers["Content-Type"] = "application/json";
//   }

//   if (options.hasOwnProperty("AdditionalParams") && options.AdditionalParams) {
//     headers = { ...headers, ...options.AdditionalParams };
//   }

//   return { headers };
// };

export const getHttpOptions = (options = defaultHeaders) => {
  let headers = {
    Authorization: "",
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": null,
    "Access-Control-Allow-credentials": true,
  };
  // "Origin, X-Requested-With, Content-Type, Accept"
  // debugger;
  if (options.hasOwnProperty("isAuth") && options.isAuth) {
    headers["Authorization"] = AuthStorage.getToken() ?? "";
  }

  if (options.hasOwnProperty("isJsonRequest") && options.isJsonRequest) {
    headers["Content-Type"] = "application/json";
  }

  if (options.hasOwnProperty("AdditionalParams") && options.AdditionalParams) {
    headers = { ...headers, ...options.AdditionalParams };
  }

  return { headers };
};
