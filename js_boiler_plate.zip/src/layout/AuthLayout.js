import React, { useState } from 'react'
import Footer from './footer/Footer'
import Header from './header/Header'

const AuthLayout = ({ children }) => {
    
    return (
        <>
            
                    <Header  />
                        {children}
                    <Footer />
        </>
    )
}

export default AuthLayout
