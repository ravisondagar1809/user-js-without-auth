const protocol = 'http';
const host = '192.168.1.15';
const port = '';
const trailUrl = 'api/v1';

const hostUrl = `${host}/`;
const endpoint = `${protocol}://${host}${(port ? ':' + port : '')}`;

export default {
    protocol: protocol,
    host: host,
    port: port,
    apiUrl: trailUrl,
    endpoint: endpoint,
    hostUrl: hostUrl,
};