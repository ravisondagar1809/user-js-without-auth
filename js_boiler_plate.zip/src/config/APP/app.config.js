const STORAGEKEY = {
    token: 'token',
    userData: 'userData',
    userId: 'userId',
    layoutData: 'layoutData',
    roles: 'roles',
    email: 'email',
    lang: 'i18nextLng',
    step: 'step',
    address:'address'
};

export default STORAGEKEY
