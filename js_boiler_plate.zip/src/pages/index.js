import React, { useEffect } from 'react'
import { Route, Routes, useLocation, useNavigate } from 'react-router-dom'
import { useDispatch } from "react-redux";
import AuthStorage from '../helper/AuthStorage'
import AuthLayout from '../layout/AuthLayout'
import { Dashboard } from './Dashboard/Dashboard';
import { isLogin } from '../redux/actions/loginAction';

const Index = () => {

    const location = useLocation()
    const navigate = useNavigate()
    const dispatch = useDispatch()
    const forLayout = []
    const forAuthLayout = ["/"]

    useEffect(() => {
        if (AuthStorage.isUserAuthenticated()) {
            if (!forAuthLayout.includes(location.pathname)) {
                navigate('/dashboard')
            }
            dispatch(isLogin(true))

        } else {
            if (!forLayout.includes(location.pathname)) {
                navigate("/");
                dispatch(isLogin(false))
                AuthStorage.deauthenticateUser()
            }
        }
    }, [location.pathname]);

    return (
        <>
          
      
                <AuthLayout>
                    <Routes>
                    <Route path="/" element={<Dashboard />} />
                    
                       
                    </Routes>
                </AuthLayout>
        
        </>
    )
}

export default Index