import { IS_LOGIN } from "../type"

export const isLogin = (value) => (dispatch) => {
    dispatch({
        type: IS_LOGIN,
        payload: value
    })
}
